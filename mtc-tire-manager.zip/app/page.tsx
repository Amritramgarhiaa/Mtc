'use client';

import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  Plus,
  Minus,
  Shield,
  Gauge,
  RotateCcw,
} from 'lucide-react';

interface TireItem {
  id: number;
  name: string;
  sku: string;
  category: string;
  categoryType: 'uhp' | 'touring' | 'all-season' | 'winter' | 'suv';
  size: string;
  speedRating: string;
  cost: number;
  stock: number;
  lowStockThreshold: number;
}

const INITIAL_TIRES: TireItem[] = [
  {
    id: 1,
    name: 'Michelin Pilot Sport 4S',
    sku: 'MTC-PS4S-245',
    category: 'Ultra High Performance',
    categoryType: 'uhp',
    size: '245/40 R19',
    speedRating: '98Y XL',
    cost: 289.00,
    stock: 14,
    lowStockThreshold: 8,
  },
  {
    id: 2,
    name: 'Pirelli P Zero Corsa',
    sku: 'MTC-PZC-265',
    category: 'Track & Competition',
    categoryType: 'uhp',
    size: '265/35 R20',
    speedRating: '99Y (Y)',
    cost: 365.00,
    stock: 4,
    lowStockThreshold: 6,
  },
  {
    id: 3,
    name: 'Continental SportContact 7',
    sku: 'MTC-SC7-255',
    category: 'Ultra High Performance',
    categoryType: 'uhp',
    size: '255/35 R19',
    speedRating: '96Y XL',
    cost: 275.00,
    stock: 18,
    lowStockThreshold: 8,
  },
  {
    id: 4,
    name: 'Bridgestone Potenza Sport',
    sku: 'MTC-PTS-225',
    category: 'High Performance',
    categoryType: 'uhp',
    size: '225/45 R18',
    speedRating: '95Y XL',
    cost: 219.00,
    stock: 9,
    lowStockThreshold: 7,
  },
  {
    id: 5,
    name: 'Goodyear Eagle F1 SuperSport',
    sku: 'MTC-F1SS-275',
    category: 'Track & Competition',
    categoryType: 'uhp',
    size: '275/35 R19',
    speedRating: '100Y XL',
    cost: 320.00,
    stock: 5,
    lowStockThreshold: 6,
  },
  {
    id: 6,
    name: 'Michelin Primacy 4+',
    sku: 'MTC-PRM4-215',
    category: 'Grand Touring',
    categoryType: 'touring',
    size: '215/55 R17',
    speedRating: '94W',
    cost: 189.00,
    stock: 24,
    lowStockThreshold: 8,
  },
  {
    id: 7,
    name: 'Pirelli Cinturato P7 C2',
    sku: 'MTC-CP7-225',
    category: 'Grand Touring',
    categoryType: 'touring',
    size: '225/50 R17',
    speedRating: '98Y XL',
    cost: 179.00,
    stock: 19,
    lowStockThreshold: 8,
  },
  {
    id: 8,
    name: 'Continental PremiumContact 7',
    sku: 'MTC-PC7-205',
    category: 'Grand Touring',
    categoryType: 'touring',
    size: '205/55 R16',
    speedRating: '91V',
    cost: 159.00,
    stock: 32,
    lowStockThreshold: 10,
  },
  {
    id: 9,
    name: 'Michelin CrossClimate 2',
    sku: 'MTC-CC2-235',
    category: 'All-Season Premium',
    categoryType: 'all-season',
    size: '235/55 R18',
    speedRating: '100V',
    cost: 235.00,
    stock: 12,
    lowStockThreshold: 6,
  },
  {
    id: 10,
    name: 'Bridgestone WeatherPeak',
    sku: 'MTC-WPK-215',
    category: 'All-Season Touring',
    categoryType: 'all-season',
    size: '215/60 R16',
    speedRating: '95H',
    cost: 172.00,
    stock: 16,
    lowStockThreshold: 8,
  },
  {
    id: 11,
    name: 'Goodyear Assurance WeatherReady',
    sku: 'MTC-AWR-225',
    category: 'All-Season',
    categoryType: 'all-season',
    size: '225/65 R17',
    speedRating: '102H',
    cost: 195.00,
    stock: 21,
    lowStockThreshold: 8,
  },
  {
    id: 12,
    name: 'Dunlop SP Sport Maxx 060+',
    sku: 'MTC-SMX-245',
    category: 'High Performance',
    categoryType: 'uhp',
    size: '245/45 R18',
    speedRating: '100Y XL',
    cost: 209.00,
    stock: 8,
    lowStockThreshold: 6,
  },
  {
    id: 13,
    name: 'Yokohama ADVAN Sport V107',
    sku: 'MTC-ADV-285',
    category: 'Ultra High Performance',
    categoryType: 'uhp',
    size: '285/30 R20',
    speedRating: '99Y XL',
    cost: 345.00,
    stock: 3,
    lowStockThreshold: 5,
  },
  {
    id: 14,
    name: 'Hankook Ventus S1 evo3',
    sku: 'MTC-EVO3-235',
    category: 'High Performance',
    categoryType: 'uhp',
    size: '235/40 R19',
    speedRating: '96Y XL',
    cost: 198.00,
    stock: 22,
    lowStockThreshold: 7,
  },
  {
    id: 15,
    name: 'Toyo Proxes Sport 2',
    sku: 'MTC-PX2-225',
    category: 'High Performance',
    categoryType: 'uhp',
    size: '225/40 R18',
    speedRating: '92Y XL',
    cost: 175.00,
    stock: 11,
    lowStockThreshold: 6,
  },
  {
    id: 16,
    name: 'Michelin Pilot Alpin 5',
    sku: 'MTC-PA5-245',
    category: 'Winter Performance',
    categoryType: 'winter',
    size: '245/40 R19',
    speedRating: '98V XL 3PMSF',
    cost: 315.00,
    stock: 7,
    lowStockThreshold: 6,
  },
  {
    id: 17,
    name: 'Bridgestone Blizzak WS90',
    sku: 'MTC-BWS90-215',
    category: 'Winter Nordic',
    categoryType: 'winter',
    size: '215/55 R17',
    speedRating: '94T 3PMSF',
    cost: 199.00,
    stock: 15,
    lowStockThreshold: 8,
  },
  {
    id: 18,
    name: 'Continental VikingContact 7',
    sku: 'MTC-VC7-225',
    category: 'Winter Nordic',
    categoryType: 'winter',
    size: '225/50 R18',
    speedRating: '99T XL 3PMSF',
    cost: 229.00,
    stock: 4,
    lowStockThreshold: 6,
  },
  {
    id: 19,
    name: 'Pirelli Scorpion Verde All Season',
    sku: 'MTC-SCV-275',
    category: 'SUV & 4x4 Luxury',
    categoryType: 'suv',
    size: '275/45 R21',
    speedRating: '110W XL',
    cost: 305.00,
    stock: 10,
    lowStockThreshold: 6,
  },
  {
    id: 20,
    name: 'BFGoodrich All-Terrain T/A KO2',
    sku: 'MTC-KO2-265',
    category: 'SUV & Off-Road',
    categoryType: 'suv',
    size: '265/70 R17',
    speedRating: '121/118S E',
    cost: 268.00,
    stock: 13,
    lowStockThreshold: 6,
  },
];

// Stylized Royal Wheel & Tyre Artwork component with bespoke SVG rendering
function TireVisual({ categoryType }: { categoryType: string }) {
  const isUhp = categoryType === 'uhp';
  const isWinter = categoryType === 'winter';
  const isSuv = categoryType === 'suv';

  return (
    <div className="relative w-full h-full flex items-center justify-center p-2 select-none group">
      {/* Outer ambient glow behind wheel */}
      <div
        className={`absolute inset-0 rounded-md transition-opacity duration-300 opacity-60 group-hover:opacity-100 ${
          isUhp
            ? 'bg-gradient-to-br from-red-600/10 via-blue-600/15 to-transparent'
            : isWinter
            ? 'bg-gradient-to-br from-blue-500/20 via-sky-600/10 to-transparent'
            : isSuv
            ? 'bg-gradient-to-br from-red-700/15 via-blue-900/20 to-transparent'
            : 'bg-gradient-to-br from-blue-600/15 via-indigo-900/20 to-transparent'
        }`}
      />

      {/* SVG Automotive Wheel & Tire Graphic */}
      <svg
        viewBox="0 0 100 100"
        className="w-16 h-16 sm:w-20 sm:h-20 drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] transition-transform duration-300 group-hover:scale-105"
        aria-hidden="true"
      >
        {/* Outer Tire Tread Surface */}
        <circle cx="50" cy="50" r="46" fill="#0d111a" stroke="#253552" strokeWidth="2" />
        
        {/* Tread Grooves pattern */}
        <circle cx="50" cy="50" r="43" fill="none" stroke="#162238" strokeWidth="3" strokeDasharray="4 2" />
        <circle cx="50" cy="50" r="39" fill="none" stroke="#090d15" strokeWidth="2" />

        {/* Sidewall Band with Royal Accent Ring */}
        <circle
          cx="50"
          cy="50"
          r="36"
          fill="#111726"
          stroke={isUhp ? '#dc2626' : '#2563eb'}
          strokeWidth="0.8"
          strokeOpacity="0.8"
        />

        {/* Wheel Rim Edge */}
        <circle cx="50" cy="50" r="28" fill="#1b253b" stroke="#3b82f6" strokeWidth="1.2" />

        {/* Brake Caliper (Royal Crimson on UHP / Royal Sapphire on others) */}
        <path
          d="M 68 38 A 22 22 0 0 0 68 62 L 64 58 A 18 18 0 0 1 64 42 Z"
          fill={isUhp || isSuv ? '#dc2626' : '#1d4ed8'}
          stroke={isUhp || isSuv ? '#ef4444' : '#60a5fa'}
          strokeWidth="0.5"
        />

        {/* Brake Rotor Disc with cooling vents */}
        <circle cx="50" cy="50" r="23" fill="#0f1624" stroke="#334155" strokeWidth="1" strokeDasharray="1.5 2" />

        {/* Wheel Spokes (Royal Multi-spoke alloy design) */}
        <g stroke="#94a3b8" strokeWidth="2.2" strokeLinecap="round">
          <line x1="50" y1="50" x2="50" y2="28" />
          <line x1="50" y1="50" x2="69" y2="36" />
          <line x1="50" y1="50" x2="66" y2="61" />
          <line x1="50" y1="50" x2="44" y2="69" />
          <line x1="50" y1="50" x2="31" y2="50" />
          <line x1="50" y1="50" x2="36" y2="34" />
        </g>

        {/* Secondary thinner alloy spokes */}
        <g stroke="#3b82f6" strokeWidth="1" strokeLinecap="round" strokeOpacity="0.8">
          <line x1="50" y1="50" x2="60" y2="30" />
          <line x1="50" y1="50" x2="70" y2="49" />
          <line x1="50" y1="50" x2="55" y2="68" />
          <line x1="50" y1="50" x2="35" y2="61" />
          <line x1="50" y1="50" x2="32" y2="42" />
        </g>

        {/* Center Hub Crest with Royal Crown motif */}
        <circle cx="50" cy="50" r="8" fill="#090e1a" stroke="#ef4444" strokeWidth="1" />
        <circle cx="50" cy="50" r="5" fill="#1e3a8a" />
        <polygon points="48,51 50,47 52,51 53,49 54,52 46,52 47,49" fill="#f8fafc" />
      </svg>

      {/* Category abbreviation badge */}
      <span className="absolute bottom-1 right-1 text-[9px] font-mono tracking-wider font-semibold uppercase text-slate-400 bg-black/60 px-1 py-0.5 rounded border border-slate-800">
        {categoryType}
      </span>
    </div>
  );
}

export default function HomePage() {
  const [tires, setTires] = useState<TireItem[]>(INITIAL_TIRES);
  const [searchQuery, setSearchQuery] = useState('');

  // Handle live stock adjustment
  const handleUpdateStock = (id: number, delta: number) => {
    setTires((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newStock = Math.max(0, item.stock + delta);
          return { ...item, stock: newStock };
        }
        return item;
      })
    );
  };

  // Filter tires by search input (case-insensitive search by tyre name, SKU, or dimensions)
  const filteredTires = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return tires;
    return tires.filter((tire) =>
      tire.name.toLowerCase().includes(q) ||
      tire.sku.toLowerCase().includes(q) ||
      tire.size.toLowerCase().includes(q)
    );
  }, [tires, searchQuery]);

  // Aggregate live units in stock
  const totalUnits = useMemo(() => {
    return tires.reduce((acc, t) => acc + t.stock, 0);
  }, [tires]);

  // Highlight search matches within tyre name
  const renderHighlightedName = (name: string, query: string) => {
    if (!query.trim()) return name;
    const parts = name.split(new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
    return (
      <>
        {parts.map((part, i) =>
          part.toLowerCase() === query.toLowerCase().trim() ? (
            <mark
              key={i}
              className="bg-red-500/30 text-white font-bold rounded-sm px-0.5 border border-red-500/50"
            >
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-red-700/50 selection:text-white">
      {/* Royal Subtle Ambient Lighting Grid */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-[500px] h-[300px] bg-blue-600/10 blur-[130px] rounded-full" />
        <div className="absolute top-0 right-1/4 w-[450px] h-[300px] bg-red-600/10 blur-[140px] rounded-full" />
      </div>

      {/* Header / Brand Top Bar with Search Input Field */}
      <header className="w-full border-b border-blue-900/40 bg-[#090e1a]/95 sticky top-0 z-50 backdrop-blur-md shadow-[0_4px_24px_-4px_rgba(15,23,42,0.8)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 sm:gap-8">
          
          {/* Zone 1: Royal Brand Mark */}
          <div className="flex items-center gap-3.5 shrink-0">
            <div className="relative w-10 h-10 rounded-lg bg-gradient-to-br from-blue-900 via-blue-950 to-black border border-blue-600/50 flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.3)]">
              <span className="text-red-500 font-extrabold text-xs tracking-tighter absolute -top-1.5 -right-1.5 px-1 py-0.2 bg-red-950 border border-red-600/80 rounded text-[9px] uppercase">
                PRO
              </span>
              <Gauge className="w-5 h-5 text-blue-400 stroke-[2.2]" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-white uppercase">
                  MTC
                </span>
                <span className="h-4 w-px bg-red-600/70" />
                <span className="text-sm sm:text-base font-semibold tracking-wide text-blue-400 uppercase">
                  Tire Manager
                </span>
              </div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-medium hidden sm:block">
                Royal Stock & Fleet Inventory
              </p>
            </div>
          </div>

          {/* Zone 2: Royal Search Input Field for filtering cards by name */}
          <div className="flex-1 max-w-xl mx-2 sm:mx-4">
            <div className="relative w-full group">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-blue-400 group-focus-within:text-red-400 transition-colors">
                <Search className="w-4 h-4 stroke-[2.2]" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter tires by name (e.g. Michelin, Pirelli, Sport)..."
                aria-label="Filter tires by name"
                className="w-full pl-10 pr-24 py-2.5 sm:py-3 bg-[#0d1527] border border-blue-900/60 rounded-xl text-xs sm:text-sm text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-600/30 transition-all shadow-inner"
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-2">
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    aria-label="Clear search input"
                    className="text-slate-400 hover:text-red-400 transition-colors p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <span className="text-[11px] font-mono text-slate-400 border-l border-slate-700/60 pl-2 hidden sm:inline">
                  {filteredTires.length} cards
                </span>
              </div>
            </div>
          </div>

          {/* Zone 3: Live Units Counter */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            <div className="text-right">
              <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">
                Live Stock Units
              </div>
              <div className="text-sm font-bold font-mono tabular-nums text-white flex items-center justify-end gap-1.5">
                <span className="text-blue-400">{totalUnits}</span>
                <span className="text-slate-600">/</span>
                <span className="text-xs text-slate-400">{tires.length} SKUs</span>
              </div>
            </div>
          </div>

        </div>
      </header>

      {/* Main Inventory Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 z-10">
        
        {/* Search Results Filter Banner (when searching) */}
        {searchQuery.trim() && (
          <div className="mb-5 flex items-center justify-between bg-[#0b1222] border border-blue-900/40 rounded-xl px-4 py-2.5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <span>Showing</span>
              <strong className="text-white font-semibold">{filteredTires.length}</strong>
              <span>of {tires.length} tyres matching</span>
              <span className="text-red-400 font-semibold">&ldquo;{searchQuery}&rdquo;</span>
            </div>
            <button
              onClick={() => setSearchQuery('')}
              className="text-red-400 hover:text-red-300 flex items-center gap-1 font-medium transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear Filter</span>
            </button>
          </div>
        )}

        {/* Empty State when Search has no matches */}
        {filteredTires.length === 0 ? (
          <div className="w-full bg-[#0b1222] border border-blue-900/50 rounded-2xl p-10 sm:p-14 text-center flex flex-col items-center justify-center my-8 shadow-lg">
            <div className="w-16 h-16 rounded-2xl bg-blue-950/70 border border-blue-800/60 flex items-center justify-center text-blue-400 mb-4">
              <Search className="w-8 h-8 stroke-[1.8]" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-white mb-2">
              No product cards matched your search
            </h3>
            <p className="text-sm text-slate-400 max-w-md mb-6">
              No inventory tire matches <span className="text-red-400 font-semibold">&ldquo;{searchQuery}&rdquo;</span>.
              Try adjusting your query or resetting the search filter.
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-red-600 hover:from-blue-500 hover:to-red-500 text-white font-medium text-xs sm:text-sm rounded-xl transition-all shadow-[0_4px_16px_rgba(37,99,235,0.3)] flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Clear Search Query</span>
            </button>
          </div>
        ) : (
          /* Product Cards Grid: Responsive 2-column grid with royal styling */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
            {filteredTires.map((tire, index) => {
              const isLow = tire.stock <= tire.lowStockThreshold;

              return (
                <React.Fragment key={tire.id}>
                  <article className="w-full bg-[#0a101d] border border-blue-950/80 rounded-xl p-4 sm:p-5 flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-blue-500/50 hover:shadow-[0_8px_30px_-6px_rgba(37,99,235,0.25)] transition-all duration-200 group">
                    {/* Top Section */}
                    <div className="flex items-center gap-3.5 sm:gap-4 pb-4">
                      {/* Left: Square Product Image area with Royal Tyre artwork */}
                      <div
                        aria-label={`Product image for ${tire.name}`}
                        className="w-20 h-20 sm:w-24 sm:h-24 aspect-square shrink-0 rounded-lg bg-[#070c17] border border-blue-900/50 flex flex-col items-center justify-center text-slate-500 relative overflow-hidden group-hover:border-blue-400/60 transition-colors"
                      >
                        <TireVisual categoryType={tire.categoryType} />
                      </div>

                      {/* Right: Product Name & Dimension Specifications */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-blue-400">
                            {tire.sku}
                          </span>
                          <span className="text-[11px] font-mono text-slate-400">
                            {tire.speedRating}
                          </span>
                        </div>

                        {/* Product Name with search highlighting */}
                        <h2 className="text-sm sm:text-base font-bold text-white tracking-tight line-clamp-1 group-hover:text-blue-300 transition-colors">
                          {renderHighlightedName(tire.name, searchQuery)}
                        </h2>

                        {/* Tyre Size & Specification */}
                        <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
                          <span className="font-mono text-slate-300 bg-blue-950/50 px-2 py-0.5 rounded border border-blue-900/40 text-[11px]">
                            {tire.size}
                          </span>
                          <span className="text-slate-500 hidden sm:inline">·</span>
                          <span className="text-[11px] text-slate-400 truncate hidden sm:inline">
                            DOT Compliant
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Thin royal horizontal divider with blue-to-red gradient between top and middle section */}
                    <div className="w-full h-px bg-gradient-to-r from-blue-900/50 via-red-900/40 to-blue-900/50 mb-3.5" />

                    {/* Middle Section: Three evenly aligned columns */}
                    <div className="grid grid-cols-3 gap-2.5 sm:gap-3.5">
                      {/* Column 1: Category */}
                      <div className="flex flex-col">
                        <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 truncate">
                          Category
                        </span>
                        {/* Value container */}
                        <div className="w-full h-9 rounded-lg bg-[#0e172a]/70 border border-blue-900/40 px-2 flex items-center">
                          <span className="text-[11px] sm:text-xs font-medium text-slate-300 truncate">
                            {tire.category}
                          </span>
                        </div>
                      </div>

                      {/* Column 2: Cost */}
                      <div className="flex flex-col">
                        <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 truncate">
                          Cost
                        </span>
                        {/* Value container with clean tabular currency */}
                        <div className="w-full h-9 rounded-lg bg-[#0e172a]/70 border border-blue-900/40 px-2.5 flex items-center justify-between">
                          <span className="text-[11px] text-slate-400">$</span>
                          <span className="text-xs sm:text-sm font-bold font-mono text-white tabular-nums">
                            {tire.cost.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      {/* Column 3: Remaining Stock with Red Accents */}
                      <div className="flex flex-col">
                        <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5 truncate flex items-center justify-between">
                          <span>Remaining Stock</span>
                          {isLow && (
                            <span className="text-red-400 text-[9px] font-bold uppercase tracking-tight">
                              Low
                            </span>
                          )}
                        </span>

                        {/* Interactive Stock Adjuster with Royal Red / Blue styling */}
                        <div
                          className={`w-full h-9 rounded-lg border relative flex items-center justify-between px-1.5 transition-colors ${
                            isLow
                              ? 'bg-red-950/40 border-red-800/80 text-red-200 shadow-[inset_0_0_10px_rgba(220,38,38,0.2)]'
                              : 'bg-blue-950/30 border-blue-900/60 text-blue-200'
                          }`}
                        >
                          {/* Decrement stock button */}
                          <button
                            type="button"
                            onClick={() => handleUpdateStock(tire.id, -1)}
                            disabled={tire.stock === 0}
                            aria-label={`Decrease stock for ${tire.name}`}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-white hover:bg-red-900/60 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>

                          {/* Live Stock Count */}
                          <span
                            className={`font-mono font-bold text-xs sm:text-sm tabular-nums px-1 ${
                              isLow ? 'text-red-400' : 'text-white'
                            }`}
                          >
                            {tire.stock}{' '}
                            <span className="text-[10px] font-sans font-normal opacity-70">
                              units
                            </span>
                          </span>

                          {/* Increment stock button */}
                          <button
                            type="button"
                            onClick={() => handleUpdateStock(tire.id, 1)}
                            aria-label={`Increase stock for ${tire.name}`}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-white hover:bg-blue-800/60 transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>

                  {/* Thin subtle horizontal divider between cards on mobile vertical stack */}
                  {index < filteredTires.length - 1 && (
                    <div className="block md:hidden w-full h-px bg-blue-950/60 my-0.5" />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        )}
      </main>

      {/* Royal Footer Section */}
      <footer className="w-full bg-[#05080f] border-t border-blue-900/40 mt-12 z-10 text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            
            {/* Column 1: Brand & Mission */}
            <div>
              <div className="flex items-center gap-2.5 mb-3">
                <div className="w-7 h-7 rounded bg-blue-900/60 border border-blue-600/50 flex items-center justify-center">
                  <Gauge className="w-4 h-4 text-blue-400" />
                </div>
                <span className="text-lg font-black text-white uppercase tracking-tight">
                  MTC <span className="text-red-500 font-bold">TIRE MANAGER</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed max-w-lg">
                Royal tire inventory & fleet stock management system. Precision tracking, structured product inventory cards, and real-time stock allocation for automotive operations.
              </p>
              <div className="mt-4 flex items-center gap-2 text-[11px] text-blue-400 font-mono">
                <Shield className="w-3.5 h-3.5 text-blue-400" />
                <span>Enterprise Grade Inventory Management</span>
              </div>
            </div>

            {/* Column 2: Tire Performance Lines & Certifications */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                <span>Performance Lines</span>
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
                <span className="hover:text-blue-300 transition-colors">Ultra High Performance</span>
                <span className="hover:text-blue-300 transition-colors">Grand Touring & Comfort</span>
                <span className="hover:text-blue-300 transition-colors">All-Season Compound</span>
                <span className="hover:text-blue-300 transition-colors">Nordic & Alpine Winter</span>
                <span className="hover:text-blue-300 transition-colors">Luxury SUV & 4x4</span>
                <span className="hover:text-blue-300 transition-colors">Track & Competition</span>
              </div>
            </div>

          </div>

          {/* Bottom Copyright & Accreditation Line */}
          <div className="pt-6 border-t border-blue-950/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
              <span>
                © 2026 MTC Tire Manager. Royal Fleet Logistics. All rights reserved.
              </span>
            </div>
            <div className="flex items-center gap-4 text-slate-400 text-[11px]">
              <span>ISO 9001 Logistics</span>
              <span>·</span>
              <span>DOT & ECE Certified</span>
              <span>·</span>
              <span className="text-red-400 font-medium">Royal Red Edition</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
