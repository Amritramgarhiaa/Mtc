import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'MTC Tire Manager',
  description: 'Professional tyre stock management system with structured product inventory cards.',
  openGraph: {
    title: 'MTC Tire Manager',
    description: 'Professional tyre stock management system with structured product inventory cards.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MTC Tire Manager',
    description: 'Professional tyre stock management system with structured product inventory cards.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning className="bg-[#070b14] text-slate-100 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
